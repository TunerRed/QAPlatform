//
// rip4xl.cpp : ���� DLL Ӧ�ó������ڵ㡣
// 
// what is this?
//    hijack bind() and connect() in order to bind
//    to a random ip if have more than one ip.
//    this is may speed up some p2p download tools
//    if you isp limits bandwidth based on ip.
//    tested ok in xp.
// qq 11348929
//    2017.4 rewrite
//

#include "stdafx.h"

#include <stdlib.h>
#include <stdio.h> 
#include <time.h> 
#include <winsock2.h>
/* ref: from winsock header file
struct sockaddr_in {
        short   sin_family;
        u_short sin_port;
        struct  in_addr sin_addr;
        char    sin_zero[8];
};
struct sockaddr {
        u_short sa_family;
        char    sa_data[14];
};
struct in_addr {
	union {
	u_long S_addr;  // 4-bytes: ip4 addr
	..
	};
};
int bind(SOCKET s, const struct sockaddr* name, int namelen);
int connect(SOCKET s, const struct sockaddr* name, int namelen);
*/

static struct in_addr iplist[21];  // 20s ip enough
static int iplist_len=0;
static int rrbin=0;

// discover all my ip, save to a list
int findout_my_iplist()
{
	if (iplist_len)
		return 0;

	int n=0; // list len
	char hname[20]="";
		gethostname(hname, 20);
	struct hostent* ph = gethostbyname(hname);
	if (ph)
	{	struct in_addr a;
		while (ph->h_addr_list[n])
		{
			a = *(struct in_addr *)ph->h_addr_list[n];
			iplist[n++] = a;
			printf("ip %s\n", inet_ntoa(a));
		}
		iplist_len=n;
	}
	return n;
}

// u cannot writable code page if not do so
int acquire_access(void* where, int len, int flag=PAGE_EXECUTE_READWRITE)
{
	DWORD old;
	BOOL b = VirtualProtect(where, len, flag, &old);
	printf("access 0x%08x ok=%d\n", where, b);
	return b;
}

// as u see name
int set_randip_if_not_setip_when_bind(DWORD* sk, int flge)
{
#if 0
	printf("flage 0x%08x\n", flge);	
	for (int i=-16; i<16; i++)
		printf("sk %08x[%d] %08x %08x\n", sk, i, sk+i, sk[i]);
#endif

	int r=0;
	SOCKET sock = sk[0]; // socket in stack
	struct sockaddr_in* pin= (struct sockaddr_in*)sk[1];
	printf("socket %d to bind %s:%d\n", sock,
		inet_ntoa(pin->sin_addr), ntohs(pin->sin_port));

	// set to random(round robin) ip
	if (pin->sin_addr.s_addr==INADDR_ANY)
	{
		pin->sin_addr = iplist[(++rrbin)%iplist_len]; 
		printf("socket %d bind rand ip %s:%d\n", sock,
			inet_ntoa(pin->sin_addr), ntohs(pin->sin_port));
	}

	return r;
}

int hij_bind()
{	
	unsigned char* bind_JMP;   // jmp from bind() to here
	unsigned char* first_FEW;  // few cmd at begin of bind(need at least 5byte)
	unsigned char* wb		// where is bind()
		= (unsigned char*)bind;

	if (wb[0]==0xe9) return 1;  // 0xe9 means hij-ed already

	_asm {	push bind_jmp  // bind_JMP = bind_jmp:;
			pop  bind_JMP 			
			push first_few // first_FEW = first_few:;
			pop  first_FEW }

	// first, copy first few cmd at begin of bind() to FEW:
	acquire_access(first_FEW, 5+5);
	memcpy(first_FEW, wb, 5);
	*(DWORD*)(first_FEW+6) = (wb+5)-(first_FEW+5+5);

	// hijacked bind()
	acquire_access(wb, 5);
	*wb = 0xe9;			// jmp to bind-jmp:
	*(DWORD*)(wb+1) = bind_JMP-(wb+5);

	return TRUE;

	_asm {
bind_jmp:		
		push 0xaaaaaaaa // +1 flg-a   4b
		pushad          // +2        32b
		push 0xbbbbbbbb // +3 flg-b   4b
		mov eax, esp
		add eax, 40     //   skip 1/2/3   now eax is esp when bind() is start
		add eax, 4      //   skip ret to sock/name/len of bind()
		push 0x11348929 // +flg-e
		push eax        // +sock&
		call set_randip_if_not_setip_when_bind
		add esp, 8      // -sock& -flg-e
		add esp, 4      // -3
		popad           // -2
		add esp, 4      // -1
first_few:
		call socket		// 5 bytes reserved
		jmp bind+5		// 1+4 bytes reserved
	}
	// never here
	return 0;
}


int bind_randip_if_not_bind_yet_when_connect(DWORD* sk, int flge)
{
	int r=0;
	SOCKET sock = sk[0]; // socket in stack
#if 0
	printf("flage 0x%08x\n", flge);
	for (int i=-16; i<16; i++)
		printf("sk %08x[%d] %08x %08x\n", sk, i, sk+i, sk[i]);
	printf("socket %d\n", sock);
	//char nam[20];
	//sprintf(nam, "c:\\bind_aaa_%d", *sk);
	//fclose(fopen(nam, "w"));
#endif

	// get and show local address
	//
		struct sockaddr name={0,0};
		struct sockaddr_in* pname = (struct sockaddr_in*)&name;
		int len=sizeof(name);
		int g = getsockname(sock, &name, &len);
		printf("socket %d current/already local name %s:%d\n",  sock, 
				inet_ntoa(pname->sin_addr), ntohs(pname->sin_port));
	
	// bind to a random ip if not bind yet
	if (pname->sin_addr.s_addr==INADDR_ANY)
	{
		struct sockaddr_in rand_addr;
		memset(&rand_addr, 0, sizeof(rand_addr));
		rand_addr.sin_family = AF_INET;
		rand_addr.sin_port = 0; //htons(34567);   // any port is ok
		rand_addr.sin_addr = iplist[rand()%iplist_len];  // INADDR_ANY
		int b = bind(sock, (struct sockaddr*)&rand_addr, sizeof(rand_addr));
		printf("try bind to %s:%d err=%d with code=%d\n", 
			inet_ntoa(rand_addr.sin_addr), ntohs(rand_addr.sin_port),
			b, GetLastError());
	}		

	return r;
}

/*
connect:
71A24A07 >   8BFF                     MOV EDI,EDI
71A24A09   . 55                       PUSH EBP
71A24A0A   . 8BEC                     MOV EBP,ESP
71A24A0C   . 83EC 18                  SUB ESP,18
...
*/


int hij_connect()
{	
	unsigned char* conn_JMP;   // jmp from connect() to here
	unsigned char* first_FEW;  // few cmd at first of connect(need at least 5b)
	unsigned char* wc		// where is connect()
			= (unsigned char*)connect;

	if (wc[0]==0xe9) return 1;  // 0xe9 means hij-ed already
	
	_asm {	push conn_jmp  // conn_JMP = conn_jmp;
			pop  conn_JMP 			
			push first_few // first_FEW = first_few;
			pop  first_FEW }

	// first, save first few cmd
	acquire_access(first_FEW, 10);
	memcpy(first_FEW, wc, 5); 
	*(DWORD*)(first_FEW+6) = (wc+5)-(first_FEW+5+5);

	// hijacked connect()
	acquire_access(wc, 5);
	*wc = 0xe9; // jmp to conn-jmp
	*(DWORD*)(wc+1) = conn_JMP-(wc+5);

	return TRUE;

	_asm {
conn_jmp:		
		push 0xaaaaaaaa // +1 flg-a   4b
		pushad          // +2        32b
		push 0xbbbbbbbb // +3 flg-b   4b
		mov eax, esp
		add eax, 40     //   skip 1/2/3   now eax is esp when connect() is start
		add eax, 4      //   skip ret to sock/name/len of connect()
		push 0x11348929 // +flg-e
		push eax        // +sock&
		call bind_randip_if_not_bind_yet_when_connect
		add esp, 8      // -sock& -flg-e
		add esp, 4      // -3
		popad           // -2
		add esp, 4      // -1

first_few: // 5 bytes
		call socket		// 5 bytes reserved
		jmp connect+5
	}	
	// never here
	return 0;
}


BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	if (ul_reason_for_call==DLL_PROCESS_ATTACH)
	{
		if (1) printf("\n");	// note: u cannnot see it if .exe is not a console app
		if (!iplist_len)
			findout_my_iplist();

		srand(time(0));			// may necessary

		hij_bind();
		printf("hijacked ok on bind()\n");
		hij_connect();
		printf("hijacked ok on connect()\n");
	}

	return TRUE;
}

